# Carbon Footprint Calculator

A school web-development project built with HTML, CSS, and Bootstrap.

## Files
- `index.html` — website structure and Bootstrap layout
- `style.css` — page styling

## Run locally
Open `index.html` in a web browser. An internet connection is needed for Bootstrap and the online nature image.

## Publish with GitHub Pages
1. Create a **public** repository on GitHub named `carbon-footprint-calculator`.
2. Upload `index.html` and `style.css` to the repository's root folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch **main** and folder **/(root)**, then click **Save**.
6. Wait for GitHub Pages to publish. Your live URL will usually be:
   `https://YOUR-USERNAME.github.io/carbon-footprint-calculator/`

Replace `YOUR-USERNAME` with your GitHub username. Check that the page opens before submitting both links to Schoology.

## Note
The introduction text in this starter version is original placeholder wording because the exact text in the reference screenshot was not provided as readable text in the assignment message. Replace it with the exact wording from the screenshot if your teacher expects a word-for-word match.
